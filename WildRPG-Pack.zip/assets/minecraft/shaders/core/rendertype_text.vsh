#version 330

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;

uniform sampler2D Sampler2;

out float sphericalVertexDistance;
out float cylindricalVertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;

// 와일드랜드 HUD: 색의 끝 비트가 (1,2,3) 인 화면(GUI) 글자만 왼쪽 위로 옮겨요
bool wrHud(vec4 c) {
    ivec3 k = ivec3(round(c.rgb * 255.0));
    return (k.r & 3) == 1 && (k.g & 3) == 2 && (k.b & 3) == 3;
}

void main() {
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);
    if (ProjMat[2][3] == 0.0 && wrHud(Color)) {
        float px = ProjMat[0][0] * ModelViewMat[0][0];
        gl_Position.x += (-1.0 + 4.0 * px) * gl_Position.w;
    }

    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);
    vertexColor = Color * texelFetch(Sampler2, UV2 / 16, 0);
    texCoord0 = UV0;
}
